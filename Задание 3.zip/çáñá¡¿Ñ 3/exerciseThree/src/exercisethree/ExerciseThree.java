/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercisethree;

/**
 *
 * @author Евгений
 */
public class ExerciseThree {


    public static void main(String[] args) {
        int arr[] = new int[10];
    for(int i = 0; i <  arr.length; i++) {
	arr[i] =  (int)(Math.random() * 100);
	System.out.print(arr[i] + "  ");
}   
    System.out.print("\nSorted: \n");
    for(int i = 0; i <  arr.length; i++) {
    if(arr[i]%3==0)
        System.out.print(arr[i] + "  ");
}
}
}
