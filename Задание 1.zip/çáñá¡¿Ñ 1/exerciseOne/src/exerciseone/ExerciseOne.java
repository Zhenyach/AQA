/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerciseone;

/**
 *
 * @author Евгений
 */
import java.util.Scanner;

public class ExerciseOne {


   public static void main(String[] args) {

       Scanner sc = new Scanner(System.in);
            System.out.println("Введите число");
            int number = sc.nextInt();
        if (number > 7) {
            System.out.println("Привет");
        }
        else {
            System.out.println("");
        }
   }
}
