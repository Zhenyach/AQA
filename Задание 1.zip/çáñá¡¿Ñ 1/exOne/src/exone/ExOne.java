/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exone;

/**
 *
 * @author Евгений
 */
import java.util.Scanner;
import javax.swing.JOptionPane;
public class ExOne {

   public static void main(String[] args) {

       Scanner sc = new Scanner(System.in);
            System.out.println("Введите число");
            int string = sc.nextInt();
        if (string > 7) {
            String full;
        full="Привет";
        
        JOptionPane.showMessageDialog(null, full);
        System.exit(0);
        }
        else {
          String full;
        full="" ;
        
        JOptionPane.showMessageDialog(null, full);
        System.exit(0);
        }
   }
}
