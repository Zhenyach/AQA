/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercisetwo;

/**
 *
 * @author Евгений
 */
import java.util.Scanner;


public class ExerciseTwo {

   
    public static void main(String[] args) {
        Scanner consl = new Scanner(System.in);
        System.out.println("Введите ваше имя");
        String text = consl.nextLine();
        String name = text.toUpperCase();
        System.out.println((name.equals("вячеслав")) ? "Привет Вячеслав" : "Нет такого имени");
            consl.close();
    } 
}
